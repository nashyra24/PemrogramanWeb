// ===== 1. Hamburger menu (JS-driven) =====
function initNavToggle() {
    const toggleBtn = document.getElementById("nav-toggle-btn");
    const nav = document.querySelector("header nav");
    if (!toggleBtn || !nav) return;
    toggleBtn.addEventListener("click", function () {
        nav.classList.toggle("nav-open");
    });
}

// Event delegation dipakai supaya tetap aman untuk perubahan struktur
// tabel di masa depan. [CATATAN] Komentar lama menyebut baris tabel
// "dirender dinamis via fetch (barang.js/peminjam.js)" — sejak Jobsheet 8
// baris dirender server-side oleh PHP dari database (meniru referensi),
// jadi barang.js & peminjam.js (versi fetch JSON) sudah tidak dipakai
// dan dihapus dari project (tersimpan di backup user).
// Logika hapus masih sekadar row.remove() di DOM (belum ke server),
// sama persis seperti kondisi referensi saat ini.
function initHapusConfirm() {
    document.addEventListener("click", function (e) {
        const btn = e.target.closest(".btn-hapus");
        if (!btn) return;

        const row = btn.closest("tr");
        const nama = row ? row.querySelector("td")?.textContent : "data ini";
        const yakin = confirm("Yakin ingin menghapus \"" + nama + "\"?");
        if (yakin && row) {
            row.remove();
        }
    });
}

// ===== 3. Filter/pencarian tabel real-time =====
function initTableFilter() {
    const input = document.getElementById("search-input");
    const table = document.querySelector(".table-responsive table");
    if (!input || !table) return;

    input.addEventListener("keyup", function () {
        const keyword = input.value.toLowerCase();
        const rows = table.querySelectorAll("tbody tr");

        rows.forEach(function (row) {
            // Memeriksa seluruh teks di dalam satu baris (semua kolom)
            const teksBaris = row.textContent.toLowerCase();
            row.style.display = teksBaris.includes(keyword) ? "" : "none";
        });

        updateTableCounter();
    });
}

// ===== 4. Validasi form (client-side) =====
function tampilkanError(input, pesan) {
    hapusError(input);
    const span = document.createElement("span");
    span.className = "error";
    span.textContent = pesan;
    input.insertAdjacentElement("afterend", span);
}

function hapusError(input) {
    const next = input.nextElementSibling;
    if (next && next.classList.contains("error")) {
        next.remove();
    }
}

function initValidasiForm() {
    const form = document.getElementById("form-tambah");
    if (!form) return;

    form.addEventListener("submit", function (e) {
        let valid = true;

        // Daftar field wajib isi
        const fieldWajib = ["nama_barang", "nama", "nim"];

        fieldWajib.forEach(function (namaField) {
            const input = form.querySelector("[name='" + namaField + "']");
            if (input) {
                if (input.value.trim() === "") {
                    tampilkanError(input, "Field ini wajib diisi.");
                    valid = false;
                } else {
                    hapusError(input);
                }
            }
        });

        // Validasi khusus angka (Jumlah)
        const jumlah = form.querySelector("[name='jumlah']");
        if (jumlah) {
            const nilai = parseInt(jumlah.value, 10);
            if (isNaN(nilai) || nilai < 0) {
                tampilkanError(jumlah, "Jumlah tidak boleh bernilai negatif.");
                valid = false;
            } else {
                hapusError(jumlah);
            }
        }

        if (!valid) {
            e.preventDefault();
        }
    });
}

//
function updateTableCounter() {
    const counter = document.getElementById("table-counter");
    const table = document.querySelector(".table-responsive table");
    if (!counter || !table) return;

    const totalBaris = table.querySelectorAll("tbody tr").length;
    let barisTampil = 0;

    table.querySelectorAll("tbody tr").forEach(function (row) {
        if (row.style.display !== "none") {
            barisTampil++;
        }
    });

    counter.textContent = "Menampilkan " + barisTampil + " dari " + totalBaris + " data";
}

// Inisialisasi setelah DOM selesai dimuat
document.addEventListener("DOMContentLoaded", function () {
    initNavToggle();
    initHapusConfirm();
    initTableFilter();
    initValidasiForm();
    updateTableCounter();
});
